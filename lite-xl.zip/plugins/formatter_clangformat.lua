-- mod-version:2 lite-xl 2.00
-- for ClangFormat formatter
local config = require "core.config"
local formatter = require "plugins.formatter"

config.clangformat_args = {"--style=llvm", "--fallback-style=llvm", "-i"}

formatter.add_formatter {
	name = "ClangFormat",
	file_patterns = {
		"%.h$", "%.inl$", "%.cpp$", "%.cc$", "%.C$", "%.cxx$",
    "%.c++$", "%.hh$", "%.H$", "%.hxx$", "%.hpp$", "%.h++$", "%.c$"
	},
	command = "clang-format $ARGS $FILENAME",
	args = config.clangformat_args
}
