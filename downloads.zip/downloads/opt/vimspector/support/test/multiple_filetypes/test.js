console.log( "Hello" );
console.log( "From" );
console.log( "JavaScript" );
