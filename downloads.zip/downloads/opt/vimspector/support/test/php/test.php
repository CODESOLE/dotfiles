<?php

$x = 1;
$y = 2;

xdebug_info();

$z = 2;
$z = 2;

?>
