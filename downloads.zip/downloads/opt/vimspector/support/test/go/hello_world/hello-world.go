package main
import "fmt"
func main() {
  var v = "test"
  fmt.Println("hello world: " + v)
}
