const main = () => {
  console.log(new Date().toISOString() + " Debugging typescript with vimspector🎉")
  console.log(new Date().toISOString() + " Done!")
}

main()
