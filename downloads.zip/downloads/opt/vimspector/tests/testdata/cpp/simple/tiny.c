int main(int argc, char**argv)
{
  int res = argc + 1;
  return res;
}
